// ── CYE - Asistente IA con Gemini Flash + Hugging Face ──
const GEMINI_API_KEY = 'AIzaSyCR9vLlkGH3RxJM64V3MnJGFFdOQ4fMM70';
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
const HF_TOKEN = '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';

let conversationHistory = [];
let isProcessing = false;
let pendingFileText = '';
let currentModel = 'gemini';

// Referencias UI (asignadas en DOMContentLoaded)
let uiStatus = null;
let welcomeName = null;
let hintStatus = null;
let sidebarStatus = null;

// ── PDF.js setup ───────────────────────────────────────
if (typeof pdfjsLib !== 'undefined') {
    pdfjsLib.GlobalWorkerOptions.workerSrc =
        'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

// ── Inicializar DOM ────────────────────────────────────
window.addEventListener('DOMContentLoaded', () => {
    uiStatus      = document.getElementById('header-model-status');
    welcomeName   = document.getElementById('welcome-model-name');
    hintStatus    = document.getElementById('hint-model-status');
    sidebarStatus = document.getElementById('sidebar-model-status');

    document.getElementById('user-input').focus();

    const savedTheme = localStorage.getItem('cye_theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    document.getElementById('btn-theme').textContent = savedTheme === 'dark' ? '☀️' : '🌙';

    const savedModel = localStorage.getItem('cye_model') || 'gemini';
    const selector = document.getElementById('model-selector');
    if (selector) {
        selector.value = savedModel;
        changeModel(savedModel);
    }
});

// ── Cambiar modelo ─────────────────────────────────────
function changeModel(model) {
    currentModel = model;
    localStorage.setItem('cye_model', model);

    const names = {
        gemini:    'Gemini 2.5 Flash',
        qwen:      'Qwen 2.5 (72B)',
        mistral:   'Mistral 7B',
        translate: 'Traductor IA'
    };
    const name = names[model] || 'Gemini 2.5 Flash';

    if (uiStatus)      uiStatus.textContent     = '· ' + name;
    if (welcomeName)   welcomeName.textContent   = name;
    if (hintStatus)    hintStatus.textContent    = name;
    if (sidebarStatus) sidebarStatus.textContent = 'Conectado · ' + name;
}

// ── Tema ───────────────────────────────────────────────
function toggleTheme() {
    const html     = document.documentElement;
    const newTheme = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', newTheme);
    document.getElementById('btn-theme').textContent = newTheme === 'dark' ? '☀️' : '🌙';
    localStorage.setItem('cye_theme', newTheme);
}

// ── Subida de archivos PDF/TXT ─────────────────────────
async function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;

    const indicator = document.getElementById('file-indicator');
    const fileName  = document.getElementById('file-name');

    if (file.type === 'application/pdf') {
        try {
            fileName.textContent = '📄 ' + file.name + ' — Extrayendo texto...';
            indicator.style.display = 'flex';

            const arrayBuffer = await file.arrayBuffer();
            const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            let fullText = '';

            for (let i = 1; i <= pdf.numPages; i++) {
                const page    = await pdf.getPage(i);
                const content = await page.getTextContent();
                fullText += '\n--- Página ' + i + ' ---\n' + content.items.map(it => it.str).join(' ');
            }

            pendingFileText = fullText.trim();
            fileName.textContent = '📄 ' + file.name + ' (' + pdf.numPages + ' págs) — Listo';

            const input = document.getElementById('user-input');
            if (!input.value.trim()) input.value = 'Analiza este documento y ayúdame con su contenido:\n';
            input.focus();
        } catch (err) {
            console.error('Error leyendo PDF:', err);
            fileName.textContent = '❌ Error al leer el PDF';
            setTimeout(() => { indicator.style.display = 'none'; }, 3000);
        }
    } else if (file.type === 'text/plain') {
        pendingFileText = await file.text();
        fileName.textContent = '📄 ' + file.name + ' — Listo';
        indicator.style.display = 'flex';

        const input = document.getElementById('user-input');
        if (!input.value.trim()) input.value = 'Analiza este documento y ayúdame con su contenido:\n';
        input.focus();
    } else {
        alert('Solo se aceptan archivos PDF o TXT.');
    }
    event.target.value = '';
}

function clearFile() {
    pendingFileText = '';
    document.getElementById('file-indicator').style.display = 'none';
    document.getElementById('pdf-upload').value = '';
}

// ── Prompts rápidos ────────────────────────────────────
function insertPrompt(text) {
    const input = document.getElementById('user-input');
    input.value = text;
    input.focus();
    autoResize(input);
}

// ── Limpiar chat ───────────────────────────────────────
function clearChat() {
    conversationHistory = [];
    document.getElementById('messages').innerHTML = `
    <div class="welcome" id="welcome-screen">
        <img src="logo.png" alt="CYE" class="welcome-logo" />
        <h2>¡Bienvenido a <span class="neon-text">CYE</span>!</h2>
        <p>Tu asistente potenciado por <strong id="welcome-model-name">Google Gemini Flash</strong>. Rápido, inteligente y listo para ayudarte.</p>
        <div class="welcome-chips">
          <span class="chip code-chip" onclick="insertPrompt('Actúa como experto programador. Ayúdame con: ')">💻 Programar</span>
          <span class="chip" onclick="insertPrompt('Traduce al inglés: ')">🌐 Traducir</span>
          <span class="chip" onclick="insertPrompt('Haz un resumen de: ')">📝 Resumir</span>
          <span class="chip" onclick="insertPrompt('Genera un texto sobre: ')">✍️ Generar</span>
          <span class="chip" onclick="insertPrompt('Crea una imagen de: ')">🎨 Imagen</span>
          <span class="chip" onclick="insertPrompt('Explícame: ')">❓ Preguntas</span>
        </div>
    </div>`;
    welcomeName = document.getElementById('welcome-model-name');
    changeModel(currentModel);
    document.getElementById('user-input').focus();
}

// ── Enviar mensaje ─────────────────────────────────────
async function sendMessage() {
    if (isProcessing) return;
    const input = document.getElementById('user-input');
    const text  = input.value.trim();
    if (!text && !pendingFileText) return;

    const welcome = document.getElementById('welcome-screen');
    if (welcome) welcome.remove();

    let fullMessage    = text;
    let displayMessage = text;

    if (pendingFileText) {
        displayMessage = '📄 [Archivo adjunto]\n' + text;
        fullMessage    = text + '\n\n--- CONTENIDO DEL DOCUMENTO ADJUNTO ---\n' +
                         pendingFileText.substring(0, 30000) + '\n--- FIN DEL DOCUMENTO ---';
        clearFile();
    }

    appendMessage('user', displayMessage);
    input.value = '';
    autoResize(input);
    conversationHistory.push({ role: 'user', parts: [{ text: fullMessage }] });

    const imageKeywords = ['crea una imagen', 'genera una imagen', 'imagen de', 'dibuja',
                           'diseña una imagen', 'crea imagen', 'genera imagen'];
    const wantsImage = imageKeywords.some(kw => text.toLowerCase().includes(kw));

    if (wantsImage) {
        await handleImageRequest(text);
    } else {
        await handleTextRequest(fullMessage);
    }
}

// ── Llamada a Hugging Face (REST, sin SDK) ─────────────
async function callHuggingFace(modelId, messages, maxTokens) {
    maxTokens = maxTokens || 2048;
    const url = 'https://api-inference.huggingface.co/models/' + modelId + '/v1/chat/completions';

    const response = await fetch(url, {
        method: 'POST',
        headers: {
            'Authorization': 'Bearer ' + HF_TOKEN,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            model: modelId,
            messages: messages,
            max_tokens: maxTokens,
            temperature: 0.7,
            stream: false
        })
    });

    if (!response.ok) {
        if (response.status === 503) throw new Error('loading');
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || 'Error HTTP ' + response.status);
    }

    const data = await response.json();
    return data.choices && data.choices[0] && data.choices[0].message
        ? data.choices[0].message.content
        : null;
}

// ── Generación de texto ────────────────────────────────
async function handleTextRequest(userText) {
    isProcessing = true;
    setLoading(true);
    const typingId = showTyping();

    try {
        let aiText = '';

        if (currentModel === 'gemini') {
            // ── GEMINI ──
            const body = {
                contents: conversationHistory.map(msg => ({ role: msg.role, parts: msg.parts })),
                generationConfig: { temperature: 0.85, topK: 40, topP: 0.95, maxOutputTokens: 2048 },
                systemInstruction: {
                    parts: [{ text: 'Eres CYE, un asistente de IA avanzado. Responde en el mismo idioma del usuario. Usa Markdown: **negrita**, listas con guiones, bloques de código con triple backtick.' }]
                }
            };
            const response = await fetch(GEMINI_API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body)
            });
            const data = await response.json();
            if (!response.ok) throw new Error(data.error && data.error.message ? data.error.message : 'Error ' + response.status);
            aiText = data.candidates && data.candidates[0] &&
                     data.candidates[0].content && data.candidates[0].content.parts &&
                     data.candidates[0].content.parts[0] ? data.candidates[0].content.parts[0].text : null;
            if (!aiText) throw new Error('Gemini no devolvió respuesta.');

        } else {
            // ── HUGGING FACE ──
            const modelMap = {
                qwen:      'Qwen/Qwen2.5-72B-Instruct',
                mistral:   'mistralai/Mistral-7B-Instruct-v0.3',
                translate: 'Qwen/Qwen2.5-72B-Instruct'
            };
            const modelId = modelMap[currentModel] || 'Qwen/Qwen2.5-72B-Instruct';

            let systemMsg = 'Eres CYE, un asistente virtual avanzado. Responde siempre en español de forma detallada. Usa Markdown para formatear: **negrita**, listas, bloques de código.';
            if (currentModel === 'translate') {
                systemMsg = 'Eres un traductor profesional. Si el texto está en español, tradúcelo al inglés. Si está en inglés, tradúcelo al español. Responde ÚNICAMENTE con la traducción, sin explicaciones adicionales.';
            }

            const messages = [
                { role: 'system', content: systemMsg },
                ...conversationHistory.map(msg => ({
                    role:    msg.role === 'user' ? 'user' : 'assistant',
                    content: msg.parts[0].text
                }))
            ];

            try {
                aiText = await callHuggingFace(modelId, messages);
                if (!aiText) throw new Error('La IA no devolvió una respuesta válida.');
            } catch (hfErr) {
                if (hfErr.message === 'loading') {
                    throw new Error('⏳ El modelo se está iniciando en Hugging Face. Espera unos 20 segundos e inténtalo de nuevo.');
                }
                throw hfErr;
            }
        }

        conversationHistory.push({ role: 'model', parts: [{ text: aiText }] });
        removeTyping(typingId);
        appendMessage('ai', aiText);

    } catch (err) {
        removeTyping(typingId);
        console.error('Error IA:', err);
        let msg = err.message;
        if (msg === 'Failed to fetch' || msg.toLowerCase().includes('network')) {
            msg = '❌ Error de red. Verifica tu conexión o cambia de modelo.';
        }
        appendMessage('ai', '❌ ' + msg);
    } finally {
        isProcessing = false;
        setLoading(false);
    }
}

// ── Generación de imágenes ─────────────────────────────
async function handleImageRequest(userText) {
    isProcessing = true;
    setLoading(true);
    const typingId = showTyping();

    try {
        const promptRes = await fetch(GEMINI_API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ role: 'user', parts: [{ text: 'Convierte esta petición en un prompt EN INGLÉS corto y descriptivo para un generador de imágenes IA. Solo responde con el prompt:\n\n"' + userText + '"' }] }],
                generationConfig: { temperature: 0.7, maxOutputTokens: 150 }
            })
        });
        const promptData = await promptRes.json();
        let imagePrompt  = promptData.candidates && promptData.candidates[0] &&
                           promptData.candidates[0].content &&
                           promptData.candidates[0].content.parts &&
                           promptData.candidates[0].content.parts[0]
            ? promptData.candidates[0].content.parts[0].text
            : userText;
        imagePrompt = imagePrompt.trim().replace(/"/g, '');

        const seed     = Math.floor(Math.random() * 100000);
        const imageUrl = 'https://image.pollinations.ai/prompt/' +
                         encodeURIComponent(imagePrompt) +
                         '?width=768&height=768&seed=' + seed + '&nologo=true';

        await new Promise((resolve, reject) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload  = resolve;
            img.onerror = reject;
            img.src     = imageUrl;
            setTimeout(() => reject(new Error('Timeout generando imagen')), 35000);
        });

        removeTyping(typingId);
        appendMessage('ai',
            '<div class="img-result">' +
                '<p>🎨 <strong>Imagen generada:</strong></p>' +
                '<img src="' + imageUrl + '" alt="' + imagePrompt + '" />' +
                '<p class="img-prompt">Prompt: <em>' + imagePrompt + '</em></p>' +
            '</div>', true);
        conversationHistory.push({ role: 'model', parts: [{ text: '[Imagen generada: ' + imagePrompt + ']' }] });

    } catch (err) {
        removeTyping(typingId);
        appendMessage('ai', '❌ No se pudo generar la imagen. Intenta con otra descripción.');
    } finally {
        isProcessing = false;
        setLoading(false);
    }
}

// ── Renderizar Markdown ────────────────────────────────
function renderMarkdown(text) {
    // Escapar HTML
    let html = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    // Bloques de código
    html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, function(_, lang, code) {
        const label = lang ? '<span class="code-lang">' + lang + '</span>' : '';
        return '<div class="code-block">' + label +
               '<pre><code>' + code.trimEnd() + '</code></pre>' +
               '<button class="copy-btn" onclick="copyCode(this)">📋 Copiar</button></div>';
    });

    // Código inline
    html = html.replace(/`([^`\n]+)`/g, '<code class="inline-code">$1</code>');

    // Encabezados
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm,  '<h2>$1</h2>');
    html = html.replace(/^# (.+)$/gm,   '<h1>$1</h1>');

    // Negrita e itálica
    html = html.replace(/\*\*\*(.+?)\*\*\*/g, '<strong><em>$1</em></strong>');
    html = html.replace(/\*\*(.+?)\*\*/g,     '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g,          '<em>$1</em>');

    // Listas
    html = html.replace(/^[\*\-\•] (.+)$/gm, '<li>$1</li>');
    html = html.replace(/^(\d+)\. (.+)$/gm,  '<li>$2</li>');
    html = html.replace(/(<li>[\s\S]*?<\/li>)/g, function(m) {
        return '<ul>' + m + '</ul>';
    });

    // Saltos de línea
    html = html.replace(/\n\n+/g, '</p><p>');
    html = html.replace(/\n/g,    '<br>');
    html = '<p>' + html + '</p>';
    html = html.replace(/<p>\s*<\/p>/g, '');

    return html;
}

function copyCode(btn) {
    const code = btn.previousElementSibling.textContent;
    navigator.clipboard.writeText(code).then(function() {
        btn.textContent = '✅ Copiado';
        setTimeout(function() { btn.textContent = '📋 Copiar'; }, 2000);
    });
}

// ── UI Helpers ─────────────────────────────────────────
function appendMessage(role, content, isHtml) {
    isHtml = isHtml || false;
    const container = document.getElementById('messages');
    const row       = document.createElement('div');
    row.className   = 'msg-row ' + role;

    const avatar     = document.createElement('div');
    avatar.className = 'msg-avatar';
    avatar.textContent = role === 'ai' ? 'CYE' : '👤';

    const bubble     = document.createElement('div');
    bubble.className = 'msg-bubble';

    if (isHtml) {
        bubble.innerHTML = content;
    } else if (role === 'ai') {
        bubble.innerHTML = renderMarkdown(content);
        bubble.classList.add('markdown');
    } else {
        bubble.textContent = content;
    }

    if (role === 'ai') {
        row.appendChild(avatar);
        row.appendChild(bubble);
    } else {
        row.appendChild(bubble);
        row.appendChild(avatar);
    }

    container.appendChild(row);
    container.scrollTop = container.scrollHeight;
}

function showTyping() {
    const container = document.getElementById('messages');
    const id  = 'typing-' + Date.now();
    const row = document.createElement('div');
    row.className = 'msg-row ai';
    row.id        = id;
    row.innerHTML =
        '<div class="msg-avatar">CYE</div>' +
        '<div class="msg-bubble"><div class="typing-dots">' +
        '<div class="dot"></div><div class="dot"></div><div class="dot"></div>' +
        '</div></div>';
    container.appendChild(row);
    container.scrollTop = container.scrollHeight;
    return id;
}

function removeTyping(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
}

function setLoading(loading) {
    document.getElementById('send-btn').disabled = loading;
}

function autoResize(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 160) + 'px';
}

function handleKeydown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
}
